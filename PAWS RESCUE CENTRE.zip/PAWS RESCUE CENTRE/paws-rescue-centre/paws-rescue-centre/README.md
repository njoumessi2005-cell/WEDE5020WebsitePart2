# Paws Rescue Centre — Website Project

## Project Title

Paws Rescue Centre Website — WEDE5020 Web Development (Introduction) PoE

## Student Information

* Name: Edwin Bresland Njoumessi Kamgang
* Student Number: ST10541990
* Module: WEDE5020

## Project Overview

Paws Rescue Centre is a non-profit animal shelter website built to showcase adoptable
animals, share information about the organisation, and allow visitors to enquire about
adoption, volunteering, sponsorship, or general contact.

## Website Goals and Objectives

* Increase awareness of the shelter and its adoptable animals.
* Generate adoption, volunteer and sponsorship enquiries via the site's forms.
* Provide an accessible, mobile-friendly experience for all visitors.

## Key Features and Functionality

* 5-page responsive website: Home, About Us, Adoptable Pets, Enquiry, Contact.
* External CSS stylesheet (`css/style.css`) shared across all pages.
* Responsive design with tablet (768px) and mobile (480px) breakpoints.
* Responsive images using `srcset`/`sizes` and the `picture` element.
* Enquiry and Contact forms with HTML5 validation attributes.
* Embedded Google Maps for two shelter locations (Johannesburg \& Pretoria).

## Sitemap

```
Home (index.html)
├── About Us (about.html)
├── Adoptable Pets (adopt.html)
├── Enquiry (enquiry.html)
└── Contact (contact.html)
```

## File and Folder Structure

```
paws-rescue-centre/
├── index.html
├── about.html
├── adopt.html
├── enquiry.html
├── contact.html
├── README.md
├── css/
│   └── style.css
├── js/
└── images/
```

## Changelog

### Part 2 — CSS Styling \& Responsive Design

* Added `css/style.css` and linked it to all five HTML pages.
* Implemented a CSS reset and CSS custom properties (variables) for consistent colours,
fonts, and spacing across the site.
* Established base typography using Google Fonts (Poppins for headings, Inter for body
text), including a defined type scale and consistent line-height/letter-spacing.
* Built the desktop layout using CSS Flexbox (header/nav, hero content, footer) and CSS
Grid (card grids, team grid, pet grid, process steps, form layout).
* Applied visual styling including colour scheme, borders, rounded corners and box-shadows
to cards, buttons, and form containers.
* Added interactive pseudo-class styling (`:hover`, `:focus`, `:active`) to navigation
links, buttons, and form fields for better usability and accessibility.
* Implemented responsive design:

  * Media queries at 768px (tablet) and 480px (mobile) breakpoints.
  * Relative units (`rem`, `em`, `%`) used throughout for font sizes and spacing.
  * Collapsible mobile navigation menu using a CSS-only checkbox toggle.
  * Responsive images using `srcset`, `sizes`, and the `<picture>` element on the hero
image; `object-fit` and `aspect-ratio` used to keep grid images consistent on all
screen sizes.
  * Grid layouts collapse from 3–4 columns (desktop) to 2 columns (tablet) to 1 column
(mobile).
* Tested layout using browser developer tools' responsive device toolbar across desktop,
tablet (iPad), and mobile (iPhone) viewport sizes. \[Insert screenshots here in your
submission as required.]

### Part 1 — Project Initiation and Planning

* Initial project setup: created five HTML files (index, about, adopt, enquiry, contact)
with semantic HTML5 structure (header, nav, main, footer).
* Established file and folder structure (css/, js/, images/).
* Added initial content for the chosen organisation, Paws Rescue Centre.

## References

Kabo (2020) White and brown english bulldog on brown wooden table. Unsplash. Available at: https://unsplash.com/photos/white-and-brown-english-bulldog-on-brown-wooden-table-RCDcigzmtII (Accessed: 25 September 2026).

Ahmed (2023) A brown dog eating food out of a metal bowl. Unsplash+. Available at: https://unsplash.com/photos/a-brown-dog-eating-food-out-of-a-metal-bowl-74vmn3E2NTo (Accessed: 19 September 2026).

Vets4Pets (n.d.) Food Guarding and Aggression. Available at: https://www.vets4pets.com/pet-health-advice/dog-advice/food-guarding/ (Accessed: 20 September 2026).

* Mozilla Developer Network (MDN) (2026) *CSS: Cascading Style Sheets*. Available at:
https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed:18 September 2026).
* Mozilla Developer Network (MDN) (2026) *Responsive images*. Available at:
https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive\_images
(Accessed: 18 September 2026).
* Google Fonts (2026) *Poppins \& Inter font families*. Available at:
https://fonts.google.com (Accessed:20 Setpember 2026).
* Unsplash (2026) *Free stock photography used for placeholder pet and team images*.
Available at: https://unsplash.com (Accessed: 20 Setpember 2026).

## 

